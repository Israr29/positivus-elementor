# Positivus — Elementor Free

Version 0.4.1. The editable WordPress project follows the supplied Positivus Figma design. The existing local page has already been updated; another import is unnecessary.

## WordPress project

Keep the Positivus Elementor Draft companion plugin active. It provides scoped styles, the local Space Grotesk font, original artwork, responsive interactions, and form shortcodes. Text, buttons, cards, images, process items, testimonials, and footer Social Icons remain editable in Elementor Free.

For a new installation, upload the plugin ZIP under Plugins → Add New Plugin → Upload Plugin, activate Elementor and this plugin, then open Tools → Positivus Import. The importer creates a draft. Updating the plugin preserves existing page data.

Set social accounts in the footer Social Icons widget → Content → Social Icons → each icon → Link. The Twitter item is displayed as X. URLs remain empty until real accounts are supplied. The JSON uses an __ASSETS__ marker resolved by the companion importer.

## Design and interactions

- Colors: #B9FF66, #191A23, #F3F3F3. Space Grotesk is bundled locally.
- Original portraits use Figma flower masks at consistent 105 × 103px dimensions.
- Navigation collapses at 1024px, with touch, keyboard, Escape, outside-click, resize, and no-JavaScript support.
- Process rows use short cancellable expansion. Testimonials support arrows, pagination, keyboard, and horizontal touch scrolling.
- Lower sections use native Elementor Fade In / Fade In Up entrance effects lasting 550ms. Reduced-motion preferences are respected. The hero paints without an entrance delay.
- Service and case-study arrows use SVG paths rendered before JavaScript. Multiline highlights include WebKit styling.

## Forms

On WordPress, contact uses wp_mail to the administrator address. Newsletter requests are stored locally. Validation, nonce verification, honeypots, length limits, rate limits, and fresh-token retries are included. Actual SMTP/mail delivery is untested; automated tests mock mail and send no messages.

The separate Netlify demo folder uses native Netlify forms and local success pages, with no PHP endpoints or WordPress tokens. Enable Netlify form detection before deployment. Verify acceptance in the dashboard after deployment. Notifications and an email-marketing provider have not been configured.

## Verification and content

See the workspace SQA-REPORT.md and NETLIFY-DEPLOY.md for exact coverage and deployment steps. Automated checks include a 1,601-width sweep, 14 representative viewports, WebKit/Chrome compatibility, backend validation, and the separate static export. This does not claim coverage of every physical device.

Remaining content choices: real social URLs, a privacy-policy destination, and review of the authored process descriptions after the first source description. Testimonials contain repeated Figma sample content.

## Source and hosting

Source: the user-provided Positivus Figma file and artwork. Preserve applicable asset licenses and attribution. The bundled font includes its OFL license. No generated replacement artwork is used.

The editable source requires WordPress hosting. Netlify provides a static presentation of that Elementor-built project; keep WordPress to demonstrate editability to HR. Never upload SQL backups, WordPress configuration, the Figma source, development dependencies, or this whole workspace to public hosting.
