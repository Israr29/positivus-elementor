<?php
if (!defined('ABSPATH')) { exit; }
function positivus_is_page() {
    return is_singular() && get_post_meta(get_queried_object_id(), '_positivus_draft', true);
}
add_action('send_headers', function () {
    if (positivus_is_page() && !headers_sent()) {
        header_remove('X-Powered-By');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('X-Frame-Options: SAMEORIGIN');
    }
});
add_filter('elementor/frontend/print_google_fonts', function ($print) { return positivus_is_page() ? false : $print; });
add_filter('document_title_parts', function ($parts) {
    if (positivus_is_page()) { unset($parts['site']); }
    return $parts;
});
add_action('wp_head', function () {
    if (positivus_is_page()) { echo '<meta name="description" content="Positivus helps businesses grow online through SEO, PPC, social media marketing, and content creation.">'; }
}, 3);
add_action('wp_head', function () {
    if (positivus_is_page()) {
        echo '<noscript><style>.px-root .elementor-invisible{visibility:visible!important;opacity:1!important;transform:none!important}.px-root .px-menu-toggle-widget{display:none!important}@media(max-width:1024px){body .elementor .px-root .px-header:not(.px-nav-ready)>.px-menu-panel{display:flex!important;position:static!important;max-height:none!important}}</style></noscript>';
    }
}, 4);
add_filter('elementor/widget/render_content', function ($content, $widget) {
    if ($widget->get_name() !== 'button' || !positivus_is_page() || !preg_match('/(?:^|\s)px-learn(?:\s|$)/', (string) $widget->get_settings('_css_classes'))) { return $content; }
    // Render the icon before JavaScript, including in Simply Static exports.
    return preg_replace_callback('/(<span\b[^>]*class="[^"]*\belementor-button-text\b[^"]*"[^>]*>)(.*?)(<\/span>)/s', function ($match) {
        $text = preg_replace('/[\x{2197}\x{FE0E}\x{FE0F}\x{3000}]/u', '', wp_strip_all_tags($match[2]));
        $text = esc_html(trim(html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
        return $match[1] . '<span class="px-learn-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="square" aria-hidden="true" focusable="false"><path d="M5 19 19 5M5 5h14v14"/></svg></span>' . $text . $match[3];
    }, $content, 1);
}, 20, 2);
add_filter('elementor/widget/render_content', function ($content, $widget) {
    if ($widget->get_name() !== 'image' || !positivus_is_page() || !class_exists('WP_HTML_Tag_Processor')) { return $content; }
    static $manifest = null;
    if ($manifest === null) { $manifest = json_decode(file_get_contents(__DIR__ . '/asset-manifest.json'), true) ?: array(); }
    $tags = new WP_HTML_Tag_Processor($content);
    while ($tags->next_tag('img')) {
        $url = $tags->get_attribute('src'); $base = plugins_url('assets/', __FILE__);
        if (!is_string($url) || (strpos($url, $base) !== 0 && strpos(wp_parse_url($url, PHP_URL_PATH) ?: '', '/wp-content/plugins/positivus-elementor-draft/assets/') === false)) { continue; }
        $filename = basename(wp_parse_url($url, PHP_URL_PATH));
        if (!isset($manifest[$filename])) { continue; }
        $asset = $manifest[$filename];
        // Rebase bundled artwork when a WordPress installation changes domain.
        $tags->set_attribute('src', $base . rawurlencode($filename));
        $tags->set_attribute('width', $asset['width']); $tags->set_attribute('height', $asset['height']);
        if (!$tags->get_attribute('alt')) { $tags->set_attribute('alt', $asset['alt']); }
        $tags->set_attribute('decoding', 'async');
        if ($filename === 'hero.svg') { $tags->set_attribute('loading', 'eager'); $tags->set_attribute('fetchpriority', 'high'); }
        elseif ($filename === 'logo.png') { $tags->set_attribute('loading', 'eager'); }
        else { $tags->set_attribute('loading', 'lazy'); }
    }
    return $tags->get_updated_html();
}, 20, 2);
add_action('wp_head', function () {
    if (positivus_is_page()) { echo '<link rel="preload" href="' . esc_url(plugins_url('assets/fonts/space-grotesk-latin.woff2', __FILE__)) . '" as="font" type="font/woff2" crossorigin>'; }
}, 2);
