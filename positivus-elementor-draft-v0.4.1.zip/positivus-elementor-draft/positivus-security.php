<?php
if (!defined('ABSPATH')) { exit; }

function positivus_post_text($name, $limit, $required = false) {
    $value = $_POST[$name] ?? '';
    if (!is_string($value) || strlen($value) > $limit) {
        wp_die('Please check your form fields.', '', array('response' => 400));
    }
    $value = trim(wp_unslash($value));
    if ($required && $value === '') { wp_die('Please complete the required fields.', '', array('response' => 400)); }
    return $value;
}

function positivus_verify_form($action, $field) {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        wp_die('Invalid request method.', '', array('response' => 405));
    }
    $nonce = $_POST[$field] ?? '';
    if (!is_string($nonce) || strlen($nonce) > 40 || !wp_verify_nonce(wp_unslash($nonce), $action)) {
        wp_die('Your form session expired. Please refresh the page and try again.', '', array('response' => 403));
    }
}

function positivus_valid_email($field) {
    $email = positivus_post_text($field, 254, true);
    if (preg_match('/[\r\n]/', $email) || !is_email($email)) {
        wp_die('Please enter a valid email address.', '', array('response' => 400));
    }
    return sanitize_email($email);
}

function positivus_submission_limit($action, $limit, $window) {
    $address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if (!is_string($address) || !filter_var($address, FILTER_VALIDATE_IP)) { $address = 'unknown'; }
    // Never trust arbitrary client-supplied forwarding headers or store raw IPs.
    $key = 'px_rate_' . $action . '_' . substr(wp_hash($address), 0, 32);
    $now = time(); $state = get_transient($key);
    if (!is_array($state) || ($state['reset'] ?? 0) <= $now) { $state = array('count' => 0, 'reset' => $now + $window); }
    if ($state['count'] >= $limit) {
        if (!headers_sent()) { header('Retry-After: ' . max(1, $state['reset'] - $now)); }
        wp_die('Too many submissions. Please try again later.', '', array('response' => 429));
    }
    $state['count']++;
    set_transient($key, $state, max(1, $state['reset'] - $now));
}

function positivus_form_redirect($parameter, $state, $fragment) {
    $fallback = get_permalink(absint(get_option('positivus_imported_draft'))) ?: home_url('/');
    $referrer = wp_get_referer();
    $url = $referrer && wp_parse_url($referrer, PHP_URL_HOST) === wp_parse_url(home_url(), PHP_URL_HOST) ? wp_validate_redirect($referrer, $fallback) : $fallback;
    $url = explode('#', $url, 2)[0];
    $url = remove_query_arg(array('px_status', 'px_news'), $url);
    wp_safe_redirect(add_query_arg($parameter, $state, $url) . '#' . $fragment, 303); exit;
}

add_action('wp_ajax_positivus_form_tokens', 'positivus_form_tokens');
add_action('wp_ajax_nopriv_positivus_form_tokens', 'positivus_form_tokens');
function positivus_form_tokens() {
    nocache_headers();
    wp_send_json_success(array('contact' => wp_create_nonce('positivus_contact'), 'newsletter' => wp_create_nonce('positivus_newsletter')));
}
