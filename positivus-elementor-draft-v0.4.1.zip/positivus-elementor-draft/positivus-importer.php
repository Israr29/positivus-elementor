<?php
/**
 * Plugin Name: Positivus Elementor Draft
 * Description: Imports the supplied Positivus draft as an editable Elementor page and provides its scoped styles.
 * Version: 0.4.1
 */
if (!defined('ABSPATH')) { exit; }
if (!defined('WP_DEBUG') || !WP_DEBUG) { ini_set('display_errors', '0'); }
require_once __DIR__ . '/positivus-security.php';
require_once __DIR__ . '/positivus-performance.php';
add_action('wp_enqueue_scripts', function () {
    if (is_singular() && get_post_meta(get_queried_object_id(), '_positivus_draft', true)) {
        wp_enqueue_style('positivus-design', plugins_url('positivus.css', __FILE__), array(), '0.4.1');
        wp_enqueue_style('positivus-fixes', plugins_url('positivus-fixes.css', __FILE__), array('positivus-design'), '0.4.1');
        wp_enqueue_style('positivus-responsive', plugins_url('positivus-responsive.css', __FILE__), array('positivus-fixes'), '0.4.1');
        wp_enqueue_script('positivus-interactions', plugins_url('positivus.js', __FILE__), array(), '0.4.1', true);
        wp_add_inline_script('positivus-interactions', 'window.positivusConfig = ' . wp_json_encode(array('newsletterHtml' => positivus_newsletter_markup(), 'assetBase' => plugins_url('assets/', __FILE__), 'tokenUrl' => add_query_arg('action','positivus_form_tokens',admin_url('admin-ajax.php'))), JSON_UNESCAPED_SLASHES) . ';', 'before');
    }
});
add_action('admin_menu', function () {
    add_management_page('Positivus Import', 'Positivus Import', 'manage_options', 'positivus-import', 'positivus_import_screen');
});
function positivus_import_screen() {
    if (!current_user_can('manage_options')) { return; }
    echo '<div class="wrap"><h1>Positivus Elementor Draft</h1><p>Version 0.4.1: responsive navigation, native entrance effects, and consistent SVG arrows. Reimport is not required.</p>';
    if (!did_action('elementor/loaded')) {
        echo '<p>Activate Elementor before importing.</p></div>'; return;
    }
    $post_id = absint(get_option('positivus_imported_draft'));
    if ($post_id && !get_post($post_id)) { $post_id = 0; }
    if (isset($_POST['positivus_import']) && !$post_id) {
        check_admin_referer('positivus_import');
        $raw = file_get_contents(__DIR__ . '/positivus-elementor.json');
        $raw = str_replace('__ASSETS__', untrailingslashit(plugins_url('assets', __FILE__)), $raw);
        $template = json_decode($raw, true);
        if (!$template || empty($template['content'])) { echo '<p>Invalid template file.</p></div>'; return; }
        $post_id = wp_insert_post(array('post_title' => 'Positivus — Design Draft', 'post_type' => 'page', 'post_status' => 'draft'), true);
        if (is_wp_error($post_id)) { echo '<p>' . esc_html($post_id->get_error_message()) . '</p></div>'; return; }
        update_post_meta($post_id, '_elementor_edit_mode', 'builder');
        update_post_meta($post_id, '_elementor_template_type', 'wp-page');
        update_post_meta($post_id, '_elementor_version', ELEMENTOR_VERSION);
        update_post_meta($post_id, '_elementor_data', wp_slash(wp_json_encode($template['content'])));
        update_post_meta($post_id, '_elementor_page_settings', array('hide_title' => 'yes'));
        update_post_meta($post_id, '_wp_page_template', 'elementor_canvas');
        update_post_meta($post_id, '_positivus_draft', '1');
        update_option('positivus_imported_draft', $post_id, false);
        \Elementor\Plugin::$instance->files_manager->clear_cache();
    }
    if ($post_id) {
        $url = admin_url('post.php?post=' . $post_id . '&action=elementor');
        echo '<p>Draft created. Existing pages have not been replaced.</p><p><a class="button button-primary" href="' . esc_url($url) . '">Edit with Elementor</a></p>';
    } else {
        echo '<p>Create a separate draft containing the Positivus layout and original artwork. Review it before publishing.</p><form method="post">';
        wp_nonce_field('positivus_import');
        submit_button('Create Elementor draft', 'primary', 'positivus_import');
        echo '</form>';
    }
    echo '</div>';
}
function positivus_newsletter_markup() {
    $state = isset($_GET['px_news']) ? sanitize_key(wp_unslash($_GET['px_news'])) : '';
    ob_start(); ?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="px-news-form">
        <input type="hidden" name="action" value="positivus_newsletter">
        <?php wp_nonce_field('positivus_newsletter', 'px_news_nonce', false); ?>
        <label class="px-sr-only" for="px-news-email">Email address for news</label>
        <input id="px-news-email" type="email" name="px_news_email" autocomplete="email" placeholder="Email" required maxlength="254">
        <input type="text" name="px_news_website" hidden tabindex="-1" autocomplete="off" aria-hidden="true">
        <button type="submit">Subscribe to news</button>
    </form>
    <?php if ($state === 'saved') { echo '<p class="px-news-status" role="status">Thank you. Your subscription request has been saved.</p>'; }
    return ob_get_clean();
}
add_shortcode('positivus_newsletter', 'positivus_newsletter_markup');
add_action('admin_post_positivus_newsletter', 'positivus_newsletter_submit');
add_action('admin_post_nopriv_positivus_newsletter', 'positivus_newsletter_submit');
function positivus_newsletter_submit() {
    positivus_verify_form('positivus_newsletter', 'px_news_nonce');
    $email = positivus_valid_email('px_news_email');
    if (positivus_post_text('px_news_website', 200) !== '') { wp_die('Please check your submission.', '', array('response' => 400)); }
    positivus_submission_limit('newsletter', 10, HOUR_IN_SECONDS);
    // Store locally; this does not subscribe anyone to an external mailing service.
    update_option('positivus_subscriber_' . hash('sha256', strtolower($email)), array('email' => $email, 'requested_at' => gmdate('c')), false);
    positivus_form_redirect('px_news', 'saved', 'newsletter');
}
add_shortcode('positivus_contact', function () {
    $status = isset($_GET['px_status']) ? sanitize_key(wp_unslash($_GET['px_status'])) : '';
    ob_start();
    if ($status === 'sent') { echo '<p role="status">Thank you. Your message was submitted.</p>'; }
    elseif ($status === 'failed') { echo '<p role="alert">Your message could not be sent. Please contact info@positivus.com.</p>'; }
    ?>
    <form class="px-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="positivus_contact">
        <?php wp_nonce_field('positivus_contact', 'px_nonce', false); ?>
        <fieldset><legend class="screen-reader-text">Reason for contacting us</legend><label><input type="radio" name="reason" value="Say Hi" checked>Say Hi</label><label><input type="radio" name="reason" value="Get a Quote">Get a Quote</label></fieldset>
        <label for="px-name">Name</label><input id="px-name" name="px_name" autocomplete="name" placeholder="Name" maxlength="150">
        <label for="px-email">Email*</label><input id="px-email" name="px_email" type="email" autocomplete="email" placeholder="Email" required maxlength="254">
        <label for="px-message">Message*</label><textarea id="px-message" name="px_message" placeholder="Message" required maxlength="10000"></textarea>
        <div hidden><label>Leave empty<input name="px_website" tabindex="-1" autocomplete="off"></label></div>
        <button type="submit">Send Message</button>
    </form>
    <?php return ob_get_clean();
});
add_action('admin_post_positivus_contact', 'positivus_contact_submit');
add_action('admin_post_nopriv_positivus_contact', 'positivus_contact_submit');
function positivus_contact_submit() {
    positivus_verify_form('positivus_contact', 'px_nonce');
    $email = positivus_valid_email('px_email');
    $message = sanitize_textarea_field(positivus_post_text('px_message', 10000, true));
    $name = sanitize_text_field(positivus_post_text('px_name', 150));
    $reason = positivus_post_text('reason', 30);
    if ($message === '' || positivus_post_text('px_website', 200) !== '' || !in_array($reason, array('Say Hi', 'Get a Quote'), true)) {
        wp_die('Please check your message.', '', array('response' => 400));
    }
    positivus_submission_limit('contact', 5, 10 * MINUTE_IN_SECONDS);
    $sent = wp_mail(get_option('admin_email'), 'Positivus: ' . $reason, "Name: $name\nEmail: $email\n\n$message", array('Reply-To: ' . $email));
    positivus_form_redirect('px_status', $sent ? 'sent' : 'failed', 'contact');
}
