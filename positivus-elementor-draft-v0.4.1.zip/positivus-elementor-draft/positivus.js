(() => {
  'use strict';
  const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const controllers = new WeakMap();
  const activeCarousels = new WeakMap();
  const navigationControllers = new WeakMap();
  const managedHeaders = new Set();
  const managedTracks = new Set();
  const forms = new WeakSet();

  function prepareForm(form) {
    if (forms.has(form)) return; forms.add(form);
    let submitting = false;
    form.addEventListener('submit', async event => {
      if (!window.positivusConfig?.tokenUrl) return;
      if (form.dataset.pxTokenReady === '1') { delete form.dataset.pxTokenReady; return; }
      event.preventDefault(); if (submitting) return;
      submitting = true;
      const button = form.querySelector('button[type="submit"]');
      if (button) button.disabled = true;
      try {
        const response = await fetch(window.positivusConfig.tokenUrl, {credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}});
        if (!response.ok) throw new Error('Token request failed');
        const data = await response.json();
        const contact = form.classList.contains('px-form');
        const token = data?.success && data.data?.[contact ? 'contact' : 'newsletter'];
        if (typeof token !== 'string' || !token) throw new Error('Invalid token response');
        form.querySelector(contact ? '[name="px_nonce"]' : '[name="px_news_nonce"]').value = token;
        form.querySelector('.px-form-error')?.remove();
        form.dataset.pxTokenReady = '1';
        if (button) button.disabled = false;
        form.requestSubmit(button || undefined);
      } catch {
        let message = form.querySelector('.px-form-error');
        if (!message) { message = document.createElement('p'); message.className = 'px-form-error'; message.setAttribute('role','alert'); form.append(message); }
        message.textContent = 'Could not connect. Please try again.';
      } finally {submitting = false; if(button) button.disabled = false;}
    });
  }

  function navigation(header) {
    const button = header.querySelector('.px-menu-toggle');
    const panel = header.querySelector('.px-menu-panel');
    if (!button || !panel || navigationControllers.get(header)?.button === button) return;
    navigationControllers.get(header)?.destroy();
    const media = window.matchMedia('(max-width: 1024px)');
    const events = new AbortController();
    panel.id = 'positivus-main-menu';
    const nav = panel.querySelector('.px-nav');
    nav?.setAttribute('role', 'navigation'); nav?.setAttribute('aria-label', 'Primary navigation');
    button.setAttribute('aria-controls', panel.id);
    let opened = false;
    function setOpen(next, restoreFocus = false) {
      opened = media.matches && next;
      header.classList.toggle('px-menu-open', opened);
      button.setAttribute('aria-expanded', String(opened));
      button.setAttribute('aria-label', opened ? 'Close navigation' : 'Open navigation');
      panel.hidden = media.matches && !opened;
      panel.inert = media.matches && !opened;
      if (restoreFocus && media.matches) button.focus();
    }
    header.classList.add('px-nav-ready'); setOpen(false);
    button.addEventListener('click', () => setOpen(!opened), {signal: events.signal});
    panel.addEventListener('click', event => {
      if (event.target.closest('a[href]')) setOpen(false);
    }, {signal: events.signal});
    document.addEventListener('pointerdown', event => {
      if (opened && !header.contains(event.target)) setOpen(false);
    }, {signal: events.signal});
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && opened) { event.preventDefault(); setOpen(false, true); }
    }, {signal: events.signal});
    header.addEventListener('focusout', event => {
      if (opened && event.relatedTarget && !header.contains(event.relatedTarget)) setOpen(false);
    }, {signal: events.signal});
    const resize = () => setOpen(false);
    media.addEventListener('change', resize);
    navigationControllers.set(header, {button, destroy() {events.abort();media.removeEventListener('change',resize)}});
    managedHeaders.add(header);
  }

  function accordion(widget) {
    const previous = controllers.get(widget);
    if (previous && previous.entries.every(entry => widget.contains(entry.title))) return;
    if (previous) {
      widget.removeEventListener('click', previous.onClick, true);
      widget.removeEventListener('keydown', previous.onKeydown, true);
      previous.entries.forEach(entry => {cancelAnimationFrame(entry.animation);clearTimeout(entry.settle)});
    }
    const rows = [...widget.querySelectorAll('.elementor-accordion-item')];
    if (!rows.length) return;
    const entries = rows.map((row, index) => {
      const title = row.querySelector('.elementor-tab-title');
      const panel = row.querySelector('.elementor-tab-content');
      if (!title || !panel) return null;
      let inner = panel.querySelector(':scope > .px-panel-inner');
      if (!inner) {
        inner = document.createElement('div'); inner.className = 'px-panel-inner';
        inner.append(...panel.childNodes); panel.append(inner);
      }
      title.setAttribute('role', 'button'); title.tabIndex = 0;
      const link = title.querySelector('.elementor-accordion-title');
      if (link) { link.tabIndex = -1; link.removeAttribute('href'); }
      panel.style.removeProperty('display');
      const state = { row, title, panel, inner, open: index === 0, animation: 0, settle: 0 };
      panel.addEventListener('transitionend', event => {
        if (event.propertyName === 'height' && state.open) panel.style.height = 'auto';
      });
      return state;
    }).filter(Boolean);
    function set(state, open, instant = false) {
      cancelAnimationFrame(state.animation);
      clearTimeout(state.settle);
      const current = state.panel.getBoundingClientRect().height;
      state.open = open;
      state.row.classList.toggle('px-open', open);
      state.title.classList.toggle('elementor-active', open);
      state.panel.classList.toggle('elementor-active', open);
      state.title.setAttribute('aria-expanded', String(open));
      state.panel.setAttribute('aria-hidden', String(!open));
      state.panel.removeAttribute('hidden');
      state.panel.inert = !open;
      if (instant || reduced()) {
        state.panel.style.height = open ? 'auto' : '0px'; return;
      }
      state.panel.style.height = current + 'px';
      // One frame sets the start height, a second commits the transition target.
      state.animation = requestAnimationFrame(() => {
        state.animation = requestAnimationFrame(() => {
          state.panel.style.height = open ? state.inner.scrollHeight + 'px' : '0px';
          // Identical start/end heights need not emit transitionend, especially
          // after rapid taps. Always restore intrinsic sizing once settled.
          state.settle = setTimeout(() => { if (state.open) state.panel.style.height = 'auto'; }, 240);
        });
      });
    }
    entries.forEach(state => {
      set(state, state.open, true);
      // Elementor may initialize after this script. Let its default activation
      // see an inactive title, so it opens rather than toggles the first row off.
      state.title.classList.remove('elementor-active');
      state.panel.classList.remove('elementor-active');
    });
    widget.classList.add('px-enhanced');
    function toggle(title) {
      const state = entries.find(s => s.title === title);
      if (!state) return;
      const next = !state.open;
      entries.forEach(entry => set(entry, entry === state && next));
    }
    const onClick = event => {
      const title = event.target.closest('.elementor-tab-title');
      if (!title) return;
      event.preventDefault(); event.stopImmediatePropagation(); toggle(title);
    };
    const onKeydown = event => {
      const title = event.target.closest('.elementor-tab-title');
      if (!title) return;
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault(); event.stopImmediatePropagation(); toggle(title);
      } else if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
        event.preventDefault(); event.stopImmediatePropagation();
        let index = entries.findIndex(s => s.title === title);
        index = event.key === 'Home' ? 0 : event.key === 'End' ? entries.length - 1 :
          (index + (event.key === 'ArrowDown' ? 1 : -1) + entries.length) % entries.length;
        entries[index].title.focus();
      }
    };
    widget.addEventListener('click', onClick, true);
    widget.addEventListener('keydown', onKeydown, true);
    controllers.set(widget, { entries, onClick, onKeydown });
  }

  function carousel(root) {
    const track = root.querySelector('.px-testimonial-track');
    if (!track) return;
    const cards = [...track.querySelectorAll('.px-testimonial')];
    if (!cards.length) return;
    const previous = activeCarousels.get(track);
    if (previous && previous.cards.length === cards.length && previous.cards.every((card,index) => cards[index] === card) && root.querySelector('.px-slider-controls') === previous.controls) return;
    const savedIndex = previous?.getIndex();
    previous?.destroy();
    const events = new AbortController();
    track.tabIndex = 0; track.setAttribute('role', 'group');
    track.setAttribute('aria-label', 'Client testimonials. Use left and right arrow keys to browse.');
    root.setAttribute('role', 'region'); root.setAttribute('aria-roledescription', 'carousel');
    root.setAttribute('aria-label', 'Client testimonials');
    let controls = root.querySelector('.px-slider-controls');
    if (!controls) return;
    // Fresh controls remove the old inline, fixed-distance scroll handlers.
    const replacement = document.createElement('div'); replacement.className = 'px-slider-controls';
    replacement.innerHTML = '<button type="button" class="px-prev" aria-label="Previous testimonial">←</button><div class="px-slider-dots" role="group" aria-label="Choose testimonial"></div><button type="button" class="px-next" aria-label="Next testimonial">→</button><span class="px-sr-only" aria-live="polite" aria-atomic="true"></span>';
    controls.replaceWith(replacement); controls = replacement;
    const dots = cards.map((card, index) => {
      card.setAttribute('role', 'group'); card.setAttribute('aria-roledescription', 'slide');
      card.setAttribute('aria-label', `${index + 1} of ${cards.length}`);
      const dot = document.createElement('button'); dot.type = 'button'; dot.textContent = '✦';
      dot.setAttribute('aria-label', `Show testimonial ${index + 1}`);
      dot.addEventListener('click', () => go(index), {signal:events.signal}); controls.querySelector('.px-slider-dots').append(dot);
      return dot;
    });
    let current = Math.min(savedIndex ?? (window.innerWidth > 767 && cards.length > 2 ? 1 : 0), cards.length - 1);
    const position = index => {
      const trackBox = track.getBoundingClientRect(), cardBox = cards[index].getBoundingClientRect();
      return track.scrollLeft + cardBox.left - trackBox.left - (track.clientWidth - cardBox.width) / 2;
    };
    function announce(index) {
      dots.forEach((dot, i) => dot.setAttribute('aria-current', String(i === index)));
      controls.querySelector('[aria-live]').textContent = `Testimonial ${index + 1} of ${cards.length}`;
      root.dataset.slideIndex = String(index);
    }
    function go(index, instant = false) {
      current = (index + cards.length) % cards.length; announce(current);
      track.scrollTo({ left: position(current), behavior: instant || reduced() ? 'instant' : 'smooth' });
    }
    controls.querySelector('.px-prev').addEventListener('click', () => go(current - 1), {signal:events.signal});
    controls.querySelector('.px-next').addEventListener('click', () => go(current + 1), {signal:events.signal});
    track.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      go(event.key === 'Home' ? 0 : event.key === 'End' ? cards.length - 1 : current + (event.key === 'ArrowRight' ? 1 : -1));
    }, {signal:events.signal});
    let scrollTimer;
    track.addEventListener('scroll', () => {
      clearTimeout(scrollTimer);
      scrollTimer = setTimeout(() => {
        const center = track.getBoundingClientRect().left + track.clientWidth / 2;
        const distances = cards.map(card => { const box = card.getBoundingClientRect(); return Math.abs(box.left + box.width / 2 - center); });
        current = distances.indexOf(Math.min(...distances)); announce(current);
      }, 100);
    }, { passive: true, signal:events.signal });
    let lastWidth = 0;
    const observer = new ResizeObserver(() => {
      const width = track.clientWidth;
      if (width > 0 && Math.abs(width - lastWidth) > 1) { lastWidth = width; requestAnimationFrame(() => go(current, true)); }
    });
    observer.observe(track);
    const firstFrame = requestAnimationFrame(() => go(current, true));
    activeCarousels.set(track, { go, cards, controls, getIndex:()=>current, destroy() {events.abort();observer.disconnect();clearTimeout(scrollTimer);cancelAnimationFrame(firstFrame)} });
    managedTracks.add(track);
  }

  function enhance(scope = document) {
    for(const header of managedHeaders)if(!header.isConnected){navigationControllers.get(header)?.destroy();navigationControllers.delete(header);managedHeaders.delete(header)}
    for(const track of managedTracks)if(!track.isConnected){activeCarousels.get(track)?.destroy();activeCarousels.delete(track);managedTracks.delete(track)}
    scope.querySelectorAll('.px-header').forEach(navigation);
    scope.querySelectorAll('.px-process').forEach(accordion);
    scope.querySelectorAll('.px-testimonials').forEach(carousel);
    scope.querySelectorAll('.px-learn .elementor-button-text').forEach(label => {
      if (label.querySelector('.px-learn-icon svg')) return;
      const copy = label.cloneNode(true);
      copy.querySelectorAll('.px-learn-icon').forEach(icon => icon.remove());
      const text = copy.textContent.replace(/[\u2197\uFE0E\uFE0F\u3000]/g, '').trim();
      const icon = document.createElement('span'); icon.className = 'px-learn-icon'; icon.setAttribute('aria-hidden', 'true');
      // A path has the same appearance on iOS, Android and desktop; Unicode arrows can become emoji.
      icon.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="square" aria-hidden="true" focusable="false"><path d="M5 19 19 5M5 5h14v14"/></svg>';
      label.replaceChildren(icon, document.createTextNode(text));
    });
    const portraits = ['ian-dooley-d1upkifd04a-unsplash-1.jpg','suad-kamardeen-khewjy5l4zo-unsplash-2.jpg','christian-buehner-ditylc26zvi-unsplash-1.jpg','feli-ramsanjami-agung-wue-q-t4-ci-unsplash-1.jpg','chanvre-quebec-mxu1spzhq6w-unsplash-1.jpg','alexandra-gorn-smus-juza9i-unsplash-1.jpg'];
    scope.querySelectorAll('.px-portrait img').forEach(image => {
      const index = portraits.findIndex(name => image.src.endsWith('/' + name));
      if (index < 0 || !window.positivusConfig?.assetBase) return;
      image.removeAttribute('srcset'); image.removeAttribute('sizes');
      image.src = window.positivusConfig.assetBase + `portrait-${index + 1}.png`;
    });
    scope.querySelectorAll('.px-newsletter').forEach(widget => {
      widget.id = 'newsletter';
      if (widget.querySelector('form') || !window.positivusConfig?.newsletterHtml) return;
      const container = widget.querySelector('.elementor-widget-container') || widget;
      container.innerHTML = window.positivusConfig.newsletterHtml;
    });
    scope.querySelectorAll('.px-socials').forEach(social => {
      if (social.querySelector('.elementor-social-icons-wrapper')) return;
      if (social.dataset.enhanced) return;
      social.innerHTML = '<span role="img" aria-label="LinkedIn">in</span><span role="img" aria-label="Facebook">f</span><span role="img" aria-label="X">𝕏</span>';
      social.dataset.enhanced = 'true';
    });
    scope.querySelectorAll('.px-form,.px-news-form').forEach(prepareForm);
  }
  function start() {
    enhance();
    let scheduled = false;
    const schedule = () => {if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;enhance()})};
    const observer = new MutationObserver(records => {
      if (scheduled || !records.some(r => [...r.addedNodes,...r.removedNodes].some(n => n.nodeType === 1 && (n.matches('.elementor-element') || n.querySelector('.elementor-element'))))) return;
      schedule();
    });
    document.querySelectorAll('.px-root').forEach(root => observer.observe(root, { childList:true, subtree:true }));
    if (window.jQuery) window.jQuery(window).on('elementor/frontend/init', () => {
      window.elementorFrontend?.hooks.addAction('frontend/element_ready/global', schedule);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
